<?php
// Start session
session_start();

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Kullanıcı zaten giriş yapmışsa ana sayfaya yönlendir
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("Location: index.php");
    exit;
}

// Login işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include "baglan.php";
    
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    // Debug bilgileri
    echo "Girilen kullanıcı adı: " . $username . "<br>";
    
    // Kullanıcı bilgilerini çek
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "Sorgu hazırlama hatası: " . $conn->error . "<br>";
        $message = "Veritabanı hatası oluştu.";
    } else {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        echo "Bulunan kullanıcı sayısı: " . $result->num_rows . "<br>";
        
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            echo "Kullanıcı ID: " . $user['id'] . "<br>";
            
            // Şifre kontrolü
            if (password_verify($password, $user['password'])) {
                echo "Şifre doğrulandı!<br>";
                // Session değişkenlerini ayarla
                $_SESSION['loggedin'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                
                // Ana sayfaya yönlendir
                header("Location: index.php");
                exit;
            } else {
                echo "Şifre doğrulanamadı!<br>";
                $message = "Geçersiz kullanıcı adı veya şifre.";
            }
        } else {
            echo "Kullanıcı bulunamadı!<br>";
            $message = "Geçersiz kullanıcı adı veya şifre.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap</title>
    <link rel="stylesheet" href="style.css">
    <link href="gul.png" rel="shortcut icon"/>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: rgb(30, 30, 30);
            transition: background-color 0.5s ease;
        }

        body:hover {
            background-color: rgb(0, 0, 0);
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            margin: 100px auto;
            padding: 30px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgb(68, 42, 36);
            text-align: center;
            transition: box-shadow 0.3s ease; 
            opacity: 0;
            transform: scale(0.95);
            animation: scaleIn 1s ease-out forwards;
        }

        @keyframes scaleIn {
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .login-container h1,
        .login-container form label,
        .login-container form input,
        .login-container form button,
        .login-container p {
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.6s ease-out forwards;
        }

        .login-container h1 { animation-delay: 0.5s; }
        .login-container form label:nth-of-type(1) { animation-delay: 0.7s; }
        .login-container form input:nth-of-type(1) { animation-delay: 0.8s; }
        .login-container form label:nth-of-type(2) { animation-delay: 0.9s; }
        .login-container form input:nth-of-type(2) { animation-delay: 1s; }
        .login-container form button { animation-delay: 1.2s; }
        .login-container p { animation-delay: 1.4s; }

        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-container:hover {
            box-shadow: 0 10px 100px rgb(255, 0, 0);
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            text-align: left;
            font-weight: bold;
        }

        input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            background-color: rgb(105, 0, 0);
            color: white;
            padding: 15px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: box-shadow 0.3s ease; 
        }

        button:hover {
            background-color: rgb(105, 0, 0);
            box-shadow: 0 10px 12px rgb(103, 0, 0); 
        }

        p {
            margin-top: 20px;
        }

        .error-message {
            color: red;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Giriş Yap</h1>
        <?php if (isset($message)): ?>
            <div class="error-message"><?php echo $message; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <label for="username">Kullanıcı Adı:</label>
            <input type="text" id="username" name="username" required>
            
            <label for="password">Şifre:</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit">Giriş Yap</button>
        </form>
        <p>Hesabınız yok mu? <a href="register.php">Kayıt Ol</a></p>
    </div>
</body>
</html>
