<?php
include "panel/config.php";

// Site ayarlarını çek
$sql = "SELECT * FROM settings LIMIT 1";
$result = mysqli_query($conn, $sql);
$settings = mysqli_fetch_assoc($result);

// Sosyal medya ayarlarını çek
$sql = "SELECT * FROM social_media WHERE id = 1";
$result = mysqli_query($conn, $sql);
$social = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
</head>
<style>
    .social-links a i {
        font-family: "Font Awesome 6 Brands" !important; /* Marka ikonları için doğru font ailesi */
        font-weight: 400 !important; /* İkonlar için normal ağırlık */
        display: inline-block !important; /* İkonun görünür olduğundan emin ol */
        font-size: 1.5em; /* İkon boyutu */
    }
     .social-links a {
        color: white; /* Bağlantı rengi */
        margin: 0 10px; /* Kenar boşluğu */
        transition: color 0.3s ease; /* Renk değişimi animasyonu */
     }
     .social-links a:hover {
        color: #6a0dad; /* Hover rengi */
     }
     .social-links span {
         display: none; /* İkon yanındaki yazıyı gizle */
     }

</style>
<!-- Footer section -->
<section class="footer-section">
	<div class="container">
		<div class="footer-logo text-center">
			<a href="index.php">
				<img src="Çiçek Buketi (3).png" alt="" width="200">
			</a>
		</div>
		<div class="row">
			<div class="col-lg-3 col-sm-6">
				<div class="footer-widget about-widget">
					<h2>Hakkımızda</h2>
					<p><?php echo $settings['site_description']; ?></p>
					<img src="img/cards.png" alt="">
				</div>
			</div>
			<div class="col-lg-3 col-sm-6">
				
			</div>
			<div class="col-lg-3 col-sm-6">
				
			</div>
			<div class="col-lg-3 col-sm-6">
				<div class="footer-widget contact-widget">
					<h2>İLETİŞİM</h2>
					<div class="con-info">
						<span>Şirketimiz</span>
						<p><?php echo $settings['site_title']; ?></p>
					</div>
					<div class="con-info">
						<span>Adres</span>
						<p><?php echo $settings['address']; ?></p>
					</div>
					<div class="con-info">
						<span>Telefon</span>
						<p><?php echo $settings['contact_phone']; ?></p>
					</div>
					<div class="con-info">
						<span>E-Mail</span>
						<p><?php echo $settings['contact_email']; ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="social-links-warp">
		<div class="container">
			<div class="social-links">
				<?php if(!empty($social['instagram'])): ?>
					<a href="<?php echo $social['instagram']; ?>" class="instagram"><i class="fa fa-instagram"></i><span>instagram</span></a>
				<?php endif; ?>
				<?php if(!empty($social['facebook'])): ?>
					<a href="<?php echo $social['facebook']; ?>" class="facebook"><i class="fa fa-facebook"></i><span>facebook</span></a>
				<?php endif; ?>
				<?php if(!empty($social['twitter'])): ?>
					<a href="<?php echo $social['twitter']; ?>" class="twitter"><i class="fa fa-twitter"></i><span>twitter</span></a>
				<?php endif; ?>
				<?php if(!empty($social['youtube'])): ?>
					<a href="<?php echo $social['youtube']; ?>" class="youtube"><i class="fa fa-youtube"></i><span>youtube</span></a>
				<?php endif; ?>
			</div>

			<p class="text-white text-center mt-5"> &copy;<script>document.write(new Date().getFullYear());</script> Tüm Hakları Saklıdır<i class="fa fa-heart-o" aria-hidden="true"></i><a href="index.php" target="_blank"><?php echo $settings['site_title']; ?></a></p>
		</div>
	}
</section>
<!-- Footer section end -->

<!--====== Javascripts & Jquery ======-->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.slicknav.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script src="js/jquery.zoom.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/main.js"></script>


</body>
</html>


