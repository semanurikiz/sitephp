<?php
include "panel/config.php"; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);


    $sql = "INSERT INTO contact_messages (name, email, subject, message, created_at) VALUES ('$name', '$email', '$subject', '$message', NOW())";

    if (mysqli_query($conn, $sql)) {

        header("Location: iletisim.php?status=success");
        exit();
    } else {
    
        echo "Hata: Mesaj gönderilemedi. " . mysqli_error($conn);
   


    mysqli_close($conn);
} else {

    echo "Hatalı istek metodu.";

?> 