<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Login kontrolü
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

include "baglan.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    
    // Formdan gelen verileri alırken input isimleriyle aynı değişken isimlerini kullan
    $ad = trim($_POST['ad'] ?? '');
    $soyad = trim($_POST['soyad'] ?? '');
    $gmail = trim($_POST['gmail'] ?? '');
    $telefon = trim($_POST['telefon'] ?? '');

    // E-posta formatını kontrol et (isteğe bağlı, ihtiyaca göre düzenlenebilir)
    if (empty($gmail) || !filter_var($gmail, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error_message'] = "Geçersiz e-posta formatı.";
        header("Location: hesabim.php");
        exit;
    }

    // Telefon numarası formatını kontrol et (isteğe bağlı, ihtiyaca göre düzenlenebilir)
    if (!empty($telefon) && !preg_match("/^[0-9]+$/", $telefon)) {
        $_SESSION['error_message'] = "Geçersiz telefon numarası formatı.";
        header("Location: hesabim.php");
        exit;
    }

    // Önce profil bilgilerinin var olup olmadığını kontrol et (user_id ile)
    // Yabancı anahtar olmadığı için sadece profil_bilgileri tablosunu kontrol ediyoruz.
    $check_sql = "SELECT id FROM profil_bilgileri WHERE user_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    if ($check_stmt) {
        $check_stmt->bind_param("i", $user_id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        $check_stmt->close();

        if ($result->num_rows > 0) {
            // Profil bilgileri varsa güncelle
            $sql = "UPDATE profil_bilgileri SET ad = ?, soyad = ?, gmail = ?, telefon = ? WHERE user_id = ?";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                 $stmt->bind_param("ssssi", $ad, $soyad, $gmail, $telefon, $user_id);
            } else {
                $_SESSION['error_message'] = "Güncelleme sorgusu hazırlama hatası: " . $conn->error;
            }
           
        } else {
            // Profil bilgileri yoksa yeni kayıt oluştur
            $sql = "INSERT INTO profil_bilgileri (user_id, ad, soyad, gmail, telefon) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
             if ($stmt) {
                $stmt->bind_param("issss", $user_id, $ad, $soyad, $gmail, $telefon);
             } else {
                 $_SESSION['error_message'] = "Ekleme sorgusu hazırlama hatası: " . $conn->error;
             }
        }

        if (isset($stmt) && $stmt->execute()) {
            $_SESSION['success_message'] = "Profil bilgileriniz başarıyla güncellendi.";
            
            // Session değişkenlerini de güncelleyelim (isteğe bağlı ama iyi bir pratik)
            $_SESSION['user_ad'] = $ad;
            $_SESSION['user_soyad'] = $soyad;
            $_SESSION['user_gmail'] = $gmail;
            $_SESSION['user_telefon'] = $telefon;

        } else if (isset($stmt)) {
            $_SESSION['error_message'] = "Profil bilgileri güncellenirken/eklenirken bir hata oluştu: " . $stmt->error;
        } else {
             // Sorgu hazırlama hatası zaten yukarıda mesaj set etmiştir.
        }

    } else {
        $_SESSION['error_message'] = "Profil bilgileri kontrol sorgusu hazırlama hatası: " . $conn->error;
    }

    header("Location: hesabim.php");
    exit;
}
?> 