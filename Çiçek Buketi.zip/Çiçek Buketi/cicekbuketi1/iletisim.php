<?php 
include "Ust.php";
?>

<style>
    .contact-section {
        padding: 60px 0; /* Add padding top and bottom */
        background-color: #fff; /* White background */
    }

    .contact-info p {
        margin-bottom: 15px; /* Space below contact info items */
        font-size: 1.1em; /* Slightly larger text */
        color: #333; /* Dark grey color */
    }

    .contact-info p i {
        margin-right: 10px; /* Space between icon and text */
        color: #6a0dad; /* Icon color */
    }

    .contact-form .form-control {
        border-radius: 5px; /* Rounded corners for form inputs */
        border: 1px solid #ccc; /* Subtle border */
        padding: 10px;
        margin-bottom: 15px; /* Space below form inputs */
    }

    .contact-form button {
        background-color: #6a0dad; /* Purple button background */
        color: white; /* White text */
        border: none; /* Remove border */
        padding: 12px 20px; /* Button padding */
        border-radius: 5px; /* Rounded button corners */
        cursor: pointer;
        transition: background-color 0.3s ease; /* Smooth hover effect */
    }

    .contact-form button:hover {
        background-color: #530a8f; /* Darker purple on hover */
    }

    .map-container {
        height: 400px; /* Set a height for the map */
        background-color: #e9ecef; /* Placeholder background */
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 1.5em;
        color: #6a0dad;
        border-radius: 10px; /* Rounded corners */
    }
</style>

<section class="contact-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2 class="mb-4">İletişim Bilgileri</h2>
                <div class="contact-info">
                    <p><i class="fas fa-map-marker-alt"></i> <strong>Adres:</strong> <?php echo $settings['address']; ?></p>
                    <p><i class="fas fa-phone"></i> <strong>Telefon:</strong> <?php echo $settings['contact_phone']; ?></p>
                    <p><i class="fas fa-envelope"></i> <strong>E-posta:</strong> <?php echo $settings['contact_email']; ?></p>
                    <p><i class="fas fa-clock"></i> <strong>Çalışma Saatleri:</strong> Hafta içi 09:00 - 18:00, Cumartesi 10:00 - 16:00</p>
                </div>
            </div>
            <div class="col-md-6">
                <h2 class="mb-4">Bize Ulaşın</h2>
                <div class="contact-form">
                    <form action="iletisim_gonder.php" method="POST">
                        <div class="form-group mb-3">
                            <label for="name">Adınız Soyadınız</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="email">E-posta Adresiniz</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="subject">Konu</label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="message">Mesajınız</label>
                            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn">Gönder</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-12">
                <div class="map-container">
                    <!-- Burada harita kodu olacak -->
                    <iframe
  width="100%"
  height="100%"
  style="border:0"
  loading="lazy"
  allowfullscreen
  referrerpolicy="no-referrer-when-downgrade"
  src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBIUZ60cbPyukB2X20PqJVN-G1l52alyqA
    &q=Space+Needle,Seattle+WA">
</iframe>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
include "alt.php";
?> 