<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Alışveriş Sepeti</title>
	<meta charset="UTF-8">
	<meta name="description" content="<?php echo $Ayar['ayar_aciklama'] ?>">
	<meta name="keywords" content="<?php echo $Ayar['ayar_kelime'] ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->
	<link href="rose.png" rel="shortcut icon"/>

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,300i,400,400i,700,700i" rel="stylesheet">


	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>
	<link rel="stylesheet" href="css/jquery-ui.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>
	<link rel="stylesheet" href="css/style.css"/>
   
    <style>





.cart-container {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    width: 100%; /* Genişliği %100 yaparak esnek yapıyoruz */
    max-width: 600px; /* Maksimum genişlik */
    margin: 20px auto; /* Üstten ve alttan boşluk bırakıyoruz */
    transition: box-shadow 0.3s ease;
}




.cart-container:hover {
    box-shadow: 0 10px 24px rgb(255, 0, 0);
}

h1 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}

.cart-items {
    margin-bottom: 20px;
}

.cart-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid #ddd;
    margin-bottom: 10px;
}

.cart-item img {
    width: 80px;
    height: 80px;
    object-fit: cover;
    border-radius: 5px;
}

.item-details {
    flex-grow: 1;
    padding-left: 15px;
}

.item-details p {
    margin: 5px 0;
    color: #555;
}

.remove-item {
    background-color: #e74c3c;
    color: white;
    padding: 8px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    transition: background-color 0.3s;
}

.remove-item:hover {
    background-color: #c0392b;
}

/* Toplam fiyat */
.total {
    text-align: right;
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 20px;
}

/* Sepet işlemleri */
.cart-actions {
    display: flex;
    justify-content: space-between;
}

.clear-cart, .checkout {
    background-color: #3498db;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 48%;
    font-size: 16px;
    transition: background-color 0.3s;
}

.clear-cart:hover, .checkout:hover {
    background-color: #2980b9;
}




</style>
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<?php
include "Ust.php"; // Ana sayfa yapısı, başlık ve menü için
?>

<div class="cart-container">
    <h1>Alışveriş Sepeti</h1>
    <div id="cart-items"></div>
    <div class="total">
        <p><strong>Toplam Fiyat: <span id="total-price">0</span> TL</strong></p>
    </div>
    <button class="clear-cart">Sepeti Temizle</button>
</div>

<?php
// Sepet işlemleri PHP kodları buraya taşınmalı veya ilgili yerlerde kullanılmalı
// Şu anki haliyle bu PHP kodları HTML yapısı içinde olduğu için sorun yaratabilir.

// Örnek: Sepet içeriğini göstermek için JavaScript kodu (zaten dosyada var gibi)
// Total fiyat hesaplama PHP kodu (veritabanı sorgusu içeriyor, dikkatli kullanılmalı)

/*
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $key => $quantity) {
        $_SESSION['cart'][$key]['quantity'] = $quantity;
    }
}
if (isset($_GET['remove_item'])) {
    $remove_item = intval($_GET['remove_item']); 
    foreach ($_SESSION['cart'] as $key => $item) {
        if ($item['product_id'] == $remove_item) {
            unset($_SESSION['cart'][$key]); 
            break;
        }
    }
   
    $_SESSION['cart'] = array_values($_SESSION['cart']);
    header("Location: cart.php");
    exit();
}
$cart_items = $_SESSION['cart'];

$total_price = 0;
foreach ($cart_items as $item) {
    $product_id = $item['product_id'];
    $quantity = $item['quantity'];

    // DİKKAT: Bu sorgu için veritabanı bağlantısı gerekiyor ($conn)
    // Ust.php içinde baglan.php var, bu bağlantıyı kullanmalı
    $sql = "SELECT urun_fiyat FROM urun WHERE id = $product_id";
    $result = $conn->query($sql); // $conn değişkeni baglan.php'den geliyor mu? Kontrol edilmeli.
    if ($result && $product = $result->fetch_assoc()) {
        $total_price += $product['price'] * $quantity;
    }
}
*/

?>

<?php
include "alt.php"; // Footer için
?>

<script>
document.addEventListener("DOMContentLoaded", function () {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let cartItemsContainer = document.getElementById("cart-items");
    let totalPriceElement = document.getElementById("total-price");

    function updateCartUI() {
        cartItemsContainer.innerHTML = "";
        let totalPrice = 0;

        cart.forEach((item, index) => {
            totalPrice += item.price * item.quantity;

            let itemElement = document.createElement("div");
            itemElement.classList.add("cart-item");
            itemElement.innerHTML = `
                <img src="/cicekbuketi1/panel/${item.image}" alt="${item.name}">
                <div class="item-details">
                    <p>${item.name}</p>
                    <p>Fiyat: ${item.price} TL</p>
                    <p>Adet: <span class="quantity">${item.quantity}</span></p>
                    <button class="remove-item" data-index="${index}">Sil</button>
                </div>
            `;
            cartItemsContainer.appendChild(itemElement);
        });

        totalPriceElement.textContent = totalPrice;
    }

    // Ürün silme işlemi
    cartItemsContainer.addEventListener("click", function (e) {
        if (e.target.classList.contains("remove-item")) {
            let index = e.target.getAttribute("data-index");
            cart.splice(index, 1);
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCartUI();
        }
    });

    // Sepeti temizleme işlemi
    document.querySelector(".clear-cart").addEventListener("click", function () {
        localStorage.removeItem("cart");
        cart = [];
        updateCartUI();
    });

    updateCartUI();
});
</script>





