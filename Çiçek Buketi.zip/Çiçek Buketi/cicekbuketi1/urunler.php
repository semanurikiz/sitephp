<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
include "Ust.php"; // Ust.php dosyası ana bağlantıyı ve stil dahilini sağlıyor
// include "panel/config.php"; // baglan.php zaten Ust.php içinde dahil ediliyor, çakışmayı önlemek için kaldırdık

// Ürünleri veritabanından çek
$sql = "SELECT *, stock FROM products"; // Stok sütunu eklendi (varsayılan: 'stock')
$result = mysqli_query($conn, $sql);
?>

<style>
    .product-container {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 30px;
        max-width: 100%;
        margin: 0 auto;
    }

    .product {
        text-align: center;
    }

    .product img {
        width: 50%;
        border-radius: 15px;
    }

    .product button {
        margin-top: 10px;
        padding: 8px 12px;
        background-color: rgb(68, 17, 17);
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .product button:hover {
        background-color: rgb(188, 0, 0);
    }

    /* Stokta olmayan ürünler için buton stili */
    .product button.out-of-stock {
        background-color: #ccc; /* Gri arka plan */
        cursor: not-allowed; /* Tıklanamaz imleci */
    }

    .product figcaption {
        margin-top: 10px;
    }

    #cart {
        margin-top: 30px;
        padding: 15px;
        border: 1px solid #ccc;
        border-radius: 10px;
    }
    
    .cart-item {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 10px;
    }

    .cart-item img {
        width: 50px;
        height: 50px;
        border-radius: 5px;
    }
</style>

<div class="section-title">
    <h2>Ürünler</h2>
</div>

<div class="product-container">
    <?php
    if(mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            ?>
            <figure class="product" 
                    data-name="<?php echo $row['name']; ?>" 
                    data-price="<?php echo $row['price']; ?>" 
                    data-image="<?php echo $row['image']; ?>"
                    data-stock="<?php echo $row['stock']; ?>"> <!-- Stok bilgisi eklendi -->
                <img src="/cicekbuketi1/panel/<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>">
                <figcaption><?php echo $row['name']; ?> <?php echo $row['price']; ?> TL</figcaption>
                <?php if ($row['stock'] > 0): ?>
                    <button class="add-to-cart">Sepete Ekle 🛒</button>
                <?php else: ?>
                    <button class="out-of-stock" disabled>Stokta Yok</button>
                <?php endif; ?>
            </figure>
            <?php
        }
    } else {
        echo "<p>Henüz ürün bulunmamaktadır.</p>";
    }
    ?>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];

        function updateCartUI() {
            let cartContainer = document.getElementById("cart-items");
            cartContainer.innerHTML = "";
            cart.forEach(item => {
                let cartItem = document.createElement("div");
                cartItem.classList.add("cart-item");
                cartItem.innerHTML = `
                    <img src="${item.image}" alt="${item.name}">
                    <span>${item.name} - ${item.price} TL (x${item.quantity})</span>
                `;
                cartContainer.appendChild(cartItem);
            });
        }

        function addToCart(product) {
            // Check if user is logged in
            <?php if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true): ?>
                alert("Ürünü sepete eklemek için lütfen giriş yapın!");
                window.location.href = "login.php";
                return;
            <?php endif; ?>

            let existingItem = cart.find(item => item.name === product.name);
            
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push(product);
            }
            
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCartUI();
            alert(product.name + " sepete eklendi!");
            updateCartItemCount();
        }

        document.querySelectorAll("button.add-to-cart").forEach(button => {
            button.addEventListener("click", function () {
                let parent = this.closest(".product");
                let product = {
                    name: parent.getAttribute("data-name"),
                    price: parseFloat(parent.getAttribute("data-price")),
                    image: parent.getAttribute("data-image"),
                    quantity: 1
                };
                addToCart(product);
            });
        });

        updateCartUI();
        updateCartItemCount();
    });

    // Ust.php içine eklediğimiz updateCartItemCount fonksiyonunu buraya da ekleyelim veya Ust.php'den çağrılsın
    // Şimdilik tekrar buraya ekliyorum ki urunler.php içinde çalışsın
     function updateCartItemCount() {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        let itemCount = 0;
        cart.forEach(item => {
            itemCount += item.quantity; // veya sadece cart.length ürün sayısı için
        });
        // Ust.php'deki span elementini güncelle
        let cartCountSpan = document.getElementById("cart-item-count");
        if (cartCountSpan) {
            cartCountSpan.textContent = itemCount; // veya cart.length
        }
    }

    // addToCart fonksiyonu içinde sepet güncellendikten sonra çağrılmalı
    // addToCart fonksiyonunu güncelliyorum
    document.addEventListener("DOMContentLoaded", function () {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];

        function updateCartUI() {
            // ... mevcut kod ...
        }

        function addToCart(product) {
            let existingItem = cart.find(item => item.name === product.name);
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push(product);
            }
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCartUI();
            alert(product.name + " sepete eklendi!");
            updateCartItemCount(); // Sepet sayısını güncelle
        }

        document.querySelectorAll("button.add-to-cart").forEach(button => {
            button.addEventListener("click", function () {
                let parent = this.closest(".product");
                let product = {
                    name: parent.getAttribute("data-name"),
                    price: parseFloat(parent.getAttribute("data-price")),
                    image: parent.getAttribute("data-image"),
                    quantity: 1 // Miktar her zaman 1 olarak eklenir
                };
                addToCart(product);
            });
        });

        updateCartUI();
        updateCartItemCount(); // Sayfa yüklendiğinde de sepet sayısını güncelle
    });

     // Ust.php içine eklediğimiz updateCartItemCount fonksiyonu (tekrarlanmış olabilir, yönetilmeli)
     // function updateCartItemCount() { ... }

</script>

<?php include "alt.php"; ?>