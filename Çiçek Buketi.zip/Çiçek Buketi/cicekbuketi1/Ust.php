<?php 
include "baglan.php";
include "fonksiyon.php";
include "panel/config.php";

// Site ayarlarını çek
$sql = "SELECT * FROM settings LIMIT 1";
$result = mysqli_query($conn, $sql);
$settings = mysqli_fetch_assoc($result);

// Sosyal medya ayarlarını çek
$sql = "SELECT * FROM social_media WHERE id = 1";
$result = mysqli_query($conn, $sql);
$social = mysqli_fetch_assoc($result);

// Start the session if it hasn't been started yet
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
	<title><?php echo $settings['site_title']; ?></title>
	<meta charset="UTF-8">
	<meta name="description" content="<?php echo $settings['site_description']; ?>">
	<meta name="keywords" content="<?php echo $Ayar['ayar_kelime'] ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link href="gul.png" rel="shortcut icon"/>


	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,300i,400,400i,700,700i" rel="stylesheet">


	
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>
	<link rel="stylesheet" href="css/jquery-ui.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/animate.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
<style>
	.image-container {
  display: flex;
  justify-content: space-around;
  align-items: center;
  margin-top: 20px;
}

.image-item {
  text-align: center;
  margin: 0 10px;
}

.image-item img {
  width: 300px;  
  height: 300px; 
  object-fit: cover;  
  border-radius: 8px;
  transition: transform 0.3s, box-shadow 0.3s;
}


.image-item .img1 {
  box-shadow: 0px 4px 8px rgba(255, 0, 0, 0.5);
}

.image-item .img1:hover {
  transform: scale(1.05);
  box-shadow: 0px 8px 16px rgba(255, 0, 0, 0.7); 
}


.image-item .img2 {
  box-shadow: 0px 4px 8px rgba(176, 86, 255, 0.5);
}

.image-item .img2:hover {
  transform: scale(1.05);
  box-shadow: 0px 8px 16px rgba(176, 86, 255, 0.7); 
}


.image-item .img3 {
  box-shadow: 0px 4px 8px rgba(244, 122, 255, 0.81); 
}

.image-item .img3:hover {
  transform: scale(1.05);
  box-shadow: 0px 8px 16px rgba(244, 122, 255, 0.81); 
}

.image-item h3 {
  margin-top: 10px;
  font-size: 18px;
  color: #333;
}
.feature-inner {
    display: flex;
    align-items: center; 
}

.feature-icon {
    margin-top: 10px; 
}

.shipping-icon {
    width: 100px;
    height: auto;
    margin-right: 15px;
}

h2 {
    margin-top: 10px; 
    font-size: 20px; 
}
.small-image {
    width: 50px; 
    height: auto; 
}

.section-title {
            text-align: center;
            margin-top: 50px;
            font-family: Arial, sans-serif;
            position: relative;
        }

        .section-title h2 {
            display: inline-block;
            position: relative;
            font-size: 36px;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .section-title h2:hover {
            transform: scale(1.1); 
        }

        .section-title h2:hover::before,
        .section-title h2:hover::after {
            content: '💐'; 
            position: absolute;
            font-size: 24px;
            animation: bloom 1s infinite alternate;
        }

        .section-title h2:hover::before {
            top: -40px;
            left: -30px;
        }

        .section-title h2:hover::after {
            top: -40px;
            right: -30px;
        }

        @keyframes bloom {
            from {
                transform: scale(0.8);
                opacity: 0.5;
            }
            to {
                transform: scale(1.2);
                opacity: 1;
            }
        }
   
</style>


</head>
<body>
	
	<div id="preloder">
		<div class="loader"></div>
	</div>


	<header class="header-section">
		<div class="header-top">
			<div class="container">
				<div class="row">
					<div class="col-lg-2 text-center text-lg-left">
		
						<a href="index.php" class="logo">
						<img src="çiçekbuket.png" alt="" style="width: 100px; height: auto; margin-top: 5px; ">

						</a>
					</div>
					<div class="col-xl-6 col-lg-5">
						<form class="header-search-form">
							<input type="text" placeholder="Çiçek Buketinde Arayın ....">
							<button><i class="flaticon-search"></i></button>
						</form>
					</div>
					<div class="col-xl-4 col-lg-5">
						<div class="user-panel">
							<div class="up-item">
								<i class="flaticon-profile"></i>
								<?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
									<a href="hesabim.php">Hesabım</a> | <a href="logout.php">Çıkış Yap</a>
								<?php else: ?>
									<a href="login.php">Giriş</a> <a href="login.php">Yap</a> yada <a href="register.php">Kayıt Ol</a>
								<?php endif; ?>
							</div>
							<div class="up-item">
								<div class="shopping-card">
									<i class="flaticon-bag"></i>
									<span id="cart-item-count">0</span>
								</div>
								<a href="cart.php">Sepetim</a>
							</div>
						</div>					
				</div>
			</div>
		</div>
		<nav class="main-navbar">
			<div class="container">
				<ul class="main-menu">
					<li><a href="index.php">Anasayfa</a></li>
					<li><a href="urunler.php">Ürünler</a></li>
					<li><a href="cicekbilgi.php">Çiçekler Hakkında bilgi</a></li>
					<li><a href="hakkimizda.php">Hakkımızda</a></li>
					<li><a href="iletisim.php">İletişim</a></li>
				</ul>
			</div>		
		</nav>
		<div class="image-container">
			<div class="image-item">
				<a href="cicekbilgi.php#gül"> <img class="img1" src="gül (2).png" alt="Gül">
				<h3>Gül Çiçeği</h3> </a>
			</div>

			<div class="image-item">
				<a href="cicekbilgi.php#lavanta">
				<img class="img2" src="lavanta.png" alt="Lavanta">
				<h3>Lavanta Çiçeği</h3> </a>
			</div>
			<div class="image-item">
				<a href="cicekbilgi.php#lale">
				<img class="img3" src="lale.jpg" alt="Lale">
				<h3>Lale Çiçeği</h3>  </a>
			</div>
		</div>
	</header>

<script>
    // Sayfa yüklendiğinde sepet sayısını güncelle
    document.addEventListener("DOMContentLoaded", function() {
        updateCartItemCount();
    });

    // Sepet sayısı güncelleme fonksiyonu
    function updateCartItemCount() {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        let itemCount = 0;
        cart.forEach(item => {
            itemCount += item.quantity; // veya sadece cart.length ürün sayısı için
        });
        let cartCountSpan = document.getElementById("cart-item-count");
        if (cartCountSpan) {
            cartCountSpan.textContent = itemCount; // veya cart.length
        }
    }

    // Ürün ekleme butonlarına olay dinleyici ekleyerek sepet sayısını güncelle
    // Bu kısım sadece ürün ekleme butonlarının olduğu sayfalarda çalışır (urunler.php gibi)
    document.querySelectorAll(".add-to-cart").forEach(button => {
        button.addEventListener("click", function() {
            // Ürün ekleme mantığınızı buraya ekleyin veya çağırın
            // Ürün başarıyla eklendikten sonra updateCartItemCount() fonksiyonunu çağırın
            // Örneğin:
            // addToCart(product); // Ürünü sepete ekleyen fonksiyonunuz
            // updateCartItemCount(); // Sayıyı güncelle

            // Mevcut ürün ekleme mantığınız urunler.php içinde JavaScript'te olduğu için,
            // o JavaScript kodunu sepet sayısını güncelleyecek şekilde düzenlemeliyiz.
            // Şimdilik, bu dinleyici her tıklandığında sayıyı güncelleyecek şekilde ayarlandı.
            // Gerçek uygulamada, sepeti güncelleyen ana fonksiyonunuzun içinde çağırılmalı.
            setTimeout(updateCartItemCount, 100); // Küçük bir gecikme ile güncelle
        });
    });

</script>

</body>
</html>

