<?php
session_start();
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    // Dosya yükleme işlemi
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $imagePath = 'uploads/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
    } else {
        $imagePath = 'default_image.jpg';
    }

    $sql = "INSERT INTO products (name, price, stock, image) VALUES (?, ?, ?, ?)";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "sdss", $name, $price, $stock, $imagePath);
        mysqli_stmt_execute($stmt);
        header("Location: products.php");
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ürün Ekle</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(-45deg, #141e30, #243b55, #0f2027, #2c5364);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
            color: white;
            font-family: 'Segoe UI', sans-serif;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .sidebar {
            min-height: 100vh;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(6px);
            color: white;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: background 0.3s ease;
            font-weight: 500;
        }

        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .content {
            padding: 40px;
            animation: fadeIn 1s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-control {
            background-color: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
        }

        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.08);
            border-color: #66afe9;
            box-shadow: none;
            color: white;
        }

        .btn-primary {
            background-color: #0d6efd;
            border: none;
            transition: background 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #0b5ed7;
        }

        .card-form {
            background-color: rgba(255, 255, 255, 0.08);
            padding: 30px;
            border-radius: 15px;
            backdrop-filter: blur(4px);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }

        label {
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-lg-2 sidebar">
                <h3 class="text-center py-3">Admin Paneli</h3>
                <a href="index.php"><i class="fas fa-home"></i> Ana Sayfa</a>
                <a href="products.php"><i class="fas fa-shopping-bag"></i> Ürünler</a>
                <a href="add_product.php"><i class="fas fa-plus"></i> Ürün Ekle</a>
                <a href="settings.php"><i class="fas fa-cog"></i> Site Ayarları</a>
                <a href="social_media.php"><i class="fas fa-share-alt"></i> Sosyal Medya</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Çıkış Yap</a>
            </div>
            <div class="col-md-9 col-lg-10 content">
                <h2 class="my-4">Yeni Ürün Ekle</h2>
                <div class="card-form">
                    <form action="add_product.php" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="name" class="form-label">Ürün Adı</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Fiyat (TL)</label>
                            <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label for="stock" class="form-label">Stok</label>
                            <input type="number" class="form-control" id="stock" name="stock" required>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Ürün Görseli</label>
                            <input type="file" class="form-control" id="image" name="image" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Ürünü Ekle</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
