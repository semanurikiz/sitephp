-- Veritabanını oluştur
CREATE DATABASE IF NOT EXISTS cicek_satis;
USE cicek_satis;

-- Admin tablosu
CREATE TABLE IF NOT EXISTS admin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Ürünler tablosu
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL,
    description TEXT,
    image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Site ayarları tablosu
CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    site_title VARCHAR(100) NOT NULL,
    site_description TEXT,
    contact_email VARCHAR(100) NOT NULL,
    contact_phone VARCHAR(20) NOT NULL,
    address TEXT
);

-- Sosyal medya tablosu
CREATE TABLE IF NOT EXISTS social_media (
    id INT PRIMARY KEY AUTO_INCREMENT,
    facebook VARCHAR(255),
    twitter VARCHAR(255),
    instagram VARCHAR(255),
    youtube VARCHAR(255)
);

-- Varsayılan admin kullanıcısı (şifre: admin123)
INSERT INTO admin (username, password) VALUES ('admin', 'admin123');

-- Varsayılan site ayarları
INSERT INTO settings (site_title, site_description, contact_email, contact_phone, address) 
VALUES ('Çiçek Satış Sitesi', 'En güzel çiçekler burada', 'info@ciceksatis.com', '0212 123 45 67', 'İstanbul, Türkiye');

-- Varsayılan sosyal medya ayarları
INSERT INTO social_media (facebook, twitter, instagram, youtube) 
VALUES ('https://facebook.com', 'https://twitter.com', 'https://instagram.com', 'https://youtube.com'); 