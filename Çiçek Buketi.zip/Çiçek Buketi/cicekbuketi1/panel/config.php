<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!defined('DB_SERVER')) {
    define('DB_SERVER', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_NAME', 'cicekbuketi1');

    // Önce veritabanı olmadan bağlantı kur
    $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);
    
    if($conn === false){
        die("HATA: Veritabanına bağlanılamadı. " . mysqli_connect_error());
    }

    // Veritabanını oluştur
    $sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci";
    if(mysqli_query($conn, $sql)) {
        // Veritabanını seç
        mysqli_select_db($conn, DB_NAME);
        
        // Tabloları oluştur
        $tables = [
            "CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                gmail VARCHAR(100) NOT NULL UNIQUE,
                ad VARCHAR(50),
                soyad VARCHAR(50),
                telefon VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci",
            
            "CREATE TABLE IF NOT EXISTS profil_bilgileri (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                ad VARCHAR(50),
                soyad VARCHAR(50),
                gmail VARCHAR(100),
                telefon VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci",
            
            "CREATE TABLE IF NOT EXISTS products (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                description TEXT,
                price DECIMAL(10,2) NOT NULL,
                image VARCHAR(255),
                stock INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci",
            
            "CREATE TABLE IF NOT EXISTS orders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                total_amount DECIMAL(10,2) NOT NULL,
                status VARCHAR(20) DEFAULT 'pending',
                FOREIGN KEY (user_id) REFERENCES users(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci",
            
            "CREATE TABLE IF NOT EXISTS addresses (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                address_title VARCHAR(50) NOT NULL,
                address TEXT NOT NULL,
                city VARCHAR(50) NOT NULL,
                district VARCHAR(50) NOT NULL,
                postal_code VARCHAR(10),
                FOREIGN KEY (user_id) REFERENCES users(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci",

            "CREATE TABLE IF NOT EXISTS settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                site_title VARCHAR(100) NOT NULL,
                site_description TEXT,
                contact_email VARCHAR(100),
                contact_phone VARCHAR(20),
                address TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci",

            "CREATE TABLE IF NOT EXISTS contact_messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                subject VARCHAR(255),
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci",

            "CREATE TABLE IF NOT EXISTS social_media (
                id INT AUTO_INCREMENT PRIMARY KEY,
                facebook VARCHAR(255),
                twitter VARCHAR(255),
                instagram VARCHAR(255),
                youtube VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci"
        ];

        foreach($tables as $sql) {
            if(!mysqli_query($conn, $sql)) {
                echo "Tablo oluşturma hatası: " . mysqli_error($conn);
            }
        }

        // Varsayılan site ayarlarını ekle
        $check_settings = "SELECT * FROM settings LIMIT 1";
        $result = mysqli_query($conn, $check_settings);
        if(mysqli_num_rows($result) == 0) {
            $sql = "INSERT INTO settings (site_title, site_description, contact_email, contact_phone, address) 
                    VALUES ('Çiçek Buketi', 'En güzel çiçekler, en uygun fiyatlarla', 'info@cicekbuketi.com', '0212 123 45 67', 'İstanbul, Türkiye')";
            mysqli_query($conn, $sql);
        }

        // Varsayılan sosyal medya ayarlarını ekle
        $check_social = "SELECT * FROM social_media LIMIT 1";
        $result = mysqli_query($conn, $check_social);
        if(mysqli_num_rows($result) == 0) {
            $sql = "INSERT INTO social_media (facebook, twitter, instagram, youtube) 
                    VALUES ('https://facebook.com/cicekbuketi', 'https://twitter.com/cicekbuketi', 'https://instagram.com/cicekbuketi', 'https://youtube.com/cicekbuketi')";
            mysqli_query($conn, $sql);
        }

        // Test kullanıcısı oluştur (eğer yoksa)
        $check_user = "SELECT * FROM users WHERE username = 'test'";
        $result = mysqli_query($conn, $check_user);
        if(mysqli_num_rows($result) == 0) {
            $sql = "INSERT INTO users (username, password, gmail, ad, soyad) 
                    VALUES ('test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'test@example.com', 'Test', 'User')";
            mysqli_query($conn, $sql);
        }
    } else {
        echo "Veritabanı oluşturma hatası: " . mysqli_error($conn);
    }
    
    // Türkçe karakter desteği
    mysqli_set_charset($conn, "utf8mb4");
}
?> 