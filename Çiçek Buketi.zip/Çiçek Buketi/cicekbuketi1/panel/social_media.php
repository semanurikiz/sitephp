<?php
session_start();
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
require_once "config.php";

// Form gönderildiyse güncelle
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $facebook = $_POST['facebook'];
    $twitter = $_POST['twitter'];
    $instagram = $_POST['instagram'];
    $youtube = $_POST['youtube'];

    $sql = "UPDATE social_media SET 
            facebook = ?,
            twitter = ?,
            instagram = ?,
            youtube = ?
            WHERE id = 1";

    if($stmt = mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "ssss", $facebook, $twitter, $instagram, $youtube);
        mysqli_stmt_execute($stmt);
        $_SESSION['success_message'] = "Sosyal medya ayarları başarıyla kaydedildi!";
        header("Location: social_media.php");
        exit;
    }
}

// Verileri çek
$sql = "SELECT * FROM social_media WHERE id = 1";
$result = mysqli_query($conn, $sql);
$social = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sosyal Medya Ayarları</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(-45deg, #1e3c72, #2a5298, #0f2027, #203a43);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
            color: white;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .sidebar {
            min-height: 100vh;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(8px);
            color: white;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: block;
            transition: background 0.3s ease;
            font-weight: 500;
        }

        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .content {
            padding: 40px;
            animation: fadeIn 1s ease;
        }

        form {
            background-color: rgba(255, 255, 255, 0.05);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(8px);
        }

        label {
            font-weight: bold;
            color: #ffffff;
            text-shadow: 0 0 5px rgba(255, 255, 255, 0.2);
        }

        .form-control {
            background-color: rgba(255,255,255,0.1);
            border: none;
            color: white;
            border-radius: 10px;
        }

        .form-control:focus {
            background-color: rgba(255,255,255,0.2);
            box-shadow: 0 0 10px #ffffff;
        }

        .btn-primary {
            background: linear-gradient(45deg, #6a11cb, #2575fc);
            border: none;
            border-radius: 8px;
            font-weight: bold;
            transition: all 0.4s ease;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
        }

        .btn-primary:hover {
            background: linear-gradient(45deg, #2575fc, #6a11cb);
            box-shadow: 0 0 20px #fff;
        }

        .alert {
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 col-lg-2 sidebar">
            <h3 class="text-center py-3">Admin Paneli</h3>
            <a href="index.php"><i class="fas fa-home"></i> Ana Sayfa</a>
            <a href="products.php"><i class="fas fa-shopping-bag"></i> Ürünler</a>
            <a href="add_product.php"><i class="fas fa-plus"></i> Ürün Ekle</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Site Ayarları</a>
            <a href="social_media.php"><i class="fas fa-share-alt"></i> Sosyal Medya</a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Çıkış Yap</a>
        </div>
        <div class="col-md-9 col-lg-10 content">
            <h2>Sosyal Medya Ayarları</h2>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php 
                        echo $_SESSION['success_message']; 
                        unset($_SESSION['success_message']);
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="mb-3">
                    <label class="form-label"><i class="fab fa-facebook"></i> Facebook</label>
                    <input type="url" name="facebook" class="form-control" value="<?php echo $social['facebook']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label"><i class="fab fa-twitter"></i> Twitter</label>
                    <input type="url" name="twitter" class="form-control" value="<?php echo $social['twitter']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label"><i class="fab fa-instagram"></i> Instagram</label>
                    <input type="url" name="instagram" class="form-control" value="<?php echo $social['instagram']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label"><i class="fab fa-youtube"></i> YouTube</label>
                    <input type="url" name="youtube" class="form-control" value="<?php echo $social['youtube']; ?>">
                </div>
                <button type="submit" class="btn btn-primary">Ayarları Kaydet</button>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
