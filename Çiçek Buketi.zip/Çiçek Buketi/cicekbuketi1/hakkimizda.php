<?php 
include "Ust.php";
?>

<style>
    .about-container {
        background-color: #f8f9fa; /* Light grey background */
        padding: 40px; /* Add some padding */
        border-radius: 10px; /* Rounded corners */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        margin-top: 30px; /* Space from the top */
        margin-bottom: 30px; /* Space from the bottom */
        opacity: 0; /* Start invisible for fade-in */
        transform: translateY(20px); /* Start slightly below */
        animation: fadeInSlideUp 1s ease-out forwards;
        position: relative; /* Needed for the absolute positioned overlay */
        overflow: hidden; /* Hide overflowing background */
    }

    .about-container::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-image: url('çiçekbuketibackground.jpg'); /* Background image path - Adjust if necessary */
        background-size: cover;
        background-position: center;
        opacity: 0.1; /* Adjust opacity as needed */
        z-index: 1; /* Place behind content */
    }

    .about-content {
        position: relative; /* Ensure content is above the overlay */
        z-index: 2;
    }

    .about-content h2, .about-content h3 {
        color: #6a0dad; /* Purple color for headings */
        margin-bottom: 15px; /* Space below headings */
        opacity: 0; /* Start invisible for fade-in */
        animation: fadeIn 0.8s ease-out forwards;
    }
    .about-content h2 {
        animation-delay: 0.3s; /* Delay heading animation */
    }
    .about-content h3 {
        animation-delay: 0.6s; /* Delay sub-heading animation */
    }
    .about-content p {
        color: #333; /* Dark grey color for text */
        line-height: 1.7; /* Improved readability */
        margin-bottom: 20px; /* Space below paragraphs */
        opacity: 0; /* Start invisible for fade-in */
        animation: fadeIn 0.8s ease-out forwards;
        animation-delay: 0.9s; /* Delay paragraph animation */
    }
    .about-content ul {
        list-style: none; /* Remove default list styling */
        padding-left: 0; /* Remove default padding */
        margin-bottom: 20px; /* Space below the list */
        opacity: 0; /* Start invisible for fade-in */
        animation: fadeIn 0.8s ease-out forwards;
        animation-delay: 1.2s; /* Delay list animation */
    }
    .about-content ul li {
        margin-bottom: 10px; /* Space between list items */
        color: #333;
        opacity: 0; /* Start invisible for fade-in */
        animation: fadeIn 0.8s ease-out forwards;
        display: flex; /* Align icon and text */
        align-items: center;
    }
    .about-content ul li i {
        margin-right: 10px; /* Space between icon and text */
        color: #6a0dad; /* Icon color */
        font-size: 1.2em; /* Increase icon size */
    }

    .about-content ul li:nth-child(1) { animation-delay: 1.5s; }
    .about-content ul li:nth-child(2) { animation-delay: 1.6s; }
    .about-content ul li:nth-child(3) { animation-delay: 1.7s; }
    .about-content ul li:nth-child(4) { animation-delay: 1.8s; }
    .about-content ul li:nth-child(5) { animation-delay: 1.9s; }

    /* Keyframes for animations */
    @keyframes fadeIn {
        to {
            opacity: 1;
        }
    }
    @keyframes fadeInSlideUp {
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="about-container">
                <h2 class="text-center mb-4">Hakkımızda</h2>
                <div class="about-content">
                    <p>Çiçek Buketi, 2024 yılında kurulmuş, müşterilerine en kaliteli çiçek ve aranjman hizmetini sunmayı hedefleyen bir çiçekçilik firmasıdır.</p>
                    
                    <h3 class="mt-4">Misyonumuz</h3>
                    <p>Müşterilerimize en taze ve kaliteli çiçekleri, uygun fiyatlarla sunarak, özel günlerinizi daha da özel kılmak.</p>
                    
                    <h3 class="mt-4">Vizyonumuz</h3>
                    <p>Türkiye'nin önde gelen çiçekçilik firmalarından biri olmak ve müşteri memnuniyetini her zaman en üst seviyede tutmak.</p>
                    
                    <h3 class="mt-4">Değerlerimiz</h3>
                    <ul>
                        <li><i class="fas fa-heart"></i> Müşteri memnuniyeti</li>
                        <li><i class="fas fa-star"></i> Kaliteli hizmet</li>
                        <li><i class="fas fa-shield-alt"></i> Güvenilirlik</li>
                        <li><i class="fas fa-lightbulb"></i> Yenilikçilik</li>
                        <li><i class="fas fa-leaf"></i> Çevre bilinci</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
include "alt.php";
?> 