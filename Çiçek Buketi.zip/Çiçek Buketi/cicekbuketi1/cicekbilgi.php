<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "Ust.php";
?>

<!DOCTYPE html>
<html lang="tr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Çiçekler Hakkında</title>
	<style>
		.gul-container {
			margin-top: 50px; 
			text-align: center; 
			padding: 20px;
		}

		.gul-container h2 {
			font-size: 24px; 
			transition: text-shadow 0.3s ease; 
			margin-bottom: 20px;
		}

		.gul-container h2:hover {
			text-shadow: 15px 15px 5px rgb(92, 255, 92);
		}

		.gul {
			display: flex; 
			align-items: center; 
			gap: 30px; 
			padding: 20px;
			justify-content: center;
			margin-bottom: 40px;
		}

		.gul img {
			width: 300px; 
			height: auto; 
			border-radius: 10px;
		}

		.gul p {
			font-size: 16px; 
			line-height: 1.6;
			text-align: left;
			max-width: 600px;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="gul-container" id="gül">
			<h2>GÜLLER</h2>
			<div class="gul">
				<img src="rose.png" alt="Gül">
				<p>Gül, güzelliği ve anlam yüklü sembolizmiyle tarih boyunca özel bir yere sahip olmuştur. 
					Latince adı Rosa olan gül, çeşitli renkleriyle farklı duyguları ifade eder. 
					Kırmızı gül aşkı, beyaz saflığı, pembe zarafeti, sarı arkadaşlığı, turuncu ise 
					coşkuyu temsil eder. Antik Yunan'dan Osmanlı'ya kadar birçok kültürde değer görmüş, 
					özellikle gül yağı ve gül suyu üretimiyle tanınmıştır. Günümüzde de kozmetik, gıda ve süs 
					bitkisi olarak yaygın şekilde kullanılan gül, sevginin ve estetiğin evrensel simgesidir🌹</p>
			</div>
		</div>

		<div class="gul-container" id="lavanta">
			<h2>LAVANTALAR</h2>
			<div class="gul">
				<img src="lavender.png" alt="lavanta">
				<p>Lavanta, hoş kokusu ve mor renkli çiçekleriyle bilinen, 
					genellikle Akdeniz iklimine özgü bir bitkidir. Latince adı Lavandula
					olan lavanta, yüzyıllardır tıbbi, kozmetik ve dekoratif amaçlarla 
					kullanılmaktadır. Rahatlatıcı etkisiyle tanınan lavanta yağı, aromaterapi
					ve uyku düzenleyici olarak tercih edilir. Ayrıca, antiseptik özellikleri 
					sayesinde cilt bakımında ve yara tedavisinde de kullanılır. Lavanta, bahçelerde
					süs bitkisi olarak yetiştirilmesinin yanı sıra, bal üretiminde de önemli
					bir rol oynar. Bu çok yönlü bitki, hem doğallığı hem de estetiğiyle hayatın
					birçok alanında değer görmektedir🪻</p>
			</div>
		</div>

		<div class="gul-container" id="lale">
			<h2>LALELER</h2>
			<div class="gul">
				<img src="tulips.png" alt="lale">
				<p>Lale, zarif ve renkli çiçekleriyle bilinen, soğanlı
					bitkiler ailesine ait bir çiçek türüdür. Özellikle bahar 
					aylarında açan laleler, sıcak iklimlerde yetişir ve genellikle 
					kırmızı, sarı, beyaz, mor ve pembe gibi canlı renklere sahiptir. 
					Lale, tarih boyunca farklı kültürlerde simgesel bir anlam taşımıştır. 
					Osmanlı İmparatorluğu'nda özellikle lale dönemi olarak bilinen bir dönem,
					bu çiçeğin popülerliğinin zirveye ulaştığı zamandır. Laleler, zarafeti 
					ve güzellikleri ile pek çok bahçe düzenlemesinin vazgeçilmez unsurlarından
					biridir. Baharın taptaze havası ve lalelerin renk cümbüşü, doğanın uyanışını simgeler🌷</p>
			</div>
		</div>
	</div>
</body>
</html>
<?php 
include "alt.php";

?>